/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.util.StringTokenizer;
import info.clearthought.layout.TableLayout;

/**
 * @author Karl Tauber
 */
public class TableSpec
{
    public static final int CENTER	= AlignmentUtil.CENTER;
	public static final int TOP		= AlignmentUtil.TOP;
	public static final int LEFT	= AlignmentUtil.LEFT;
	public static final int BOTTOM	= AlignmentUtil.BOTTOM;
	public static final int RIGHT	= AlignmentUtil.RIGHT;
	public static final int FILL	= AlignmentUtil.FILL;

	public static final int DEFAULT_ALIGN = FILL;
	public static final double DEFAULT_SIZE = TableLayout.PREFERRED;

    private int defaultAlignment;
	private double size;

	public TableSpec() {
		this( DEFAULT_ALIGN, DEFAULT_SIZE );
	}

	public TableSpec( int defaultAlignment, double size ) {
		this.defaultAlignment = defaultAlignment;
		this.size = size;
	}

	public TableSpec( String encodedDescription ) {
		this();

		StringTokenizer st = new StringTokenizer( encodedDescription, ":" );
		if( !st.hasMoreTokens() )
			throw new IllegalArgumentException( encodedDescription );

		int tokenCount = st.countTokens();
		String token = st.nextToken();

		if( tokenCount >= 2 ) {
			int alignment = AlignmentUtil.toValue( token );
			if( alignment >= 0 ) {
				defaultAlignment = alignment;
				token = st.nextToken();
			}
		}

		if( token.equals( "fill" ) )
			size = TableLayout.FILL;
		else if( token.equals( "pref" ) )
			size = TableLayout.PREFERRED;
		else if( token.equals( "min" ) )
			size = TableLayout.MINIMUM;
		else
			size = Double.parseDouble( token );
	}

	public int getDefaultAlignment() {
		return defaultAlignment;
	}

	public double getSize() {
		return size;
	}

	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		if( defaultAlignment != DEFAULT_ALIGN ) {
			buf.append( AlignmentUtil.toName( defaultAlignment ) );
			buf.append( ':' );
		}

		if( size == TableLayout.FILL )
			buf.append( "fill" );
		else if( size == TableLayout.PREFERRED )
			buf.append( "pref" );
		else if( size == TableLayout.MINIMUM )
			buf.append( "min" );
		else
			buf.append( size );
		return buf.toString();
	}

	public static String toString( int alignment ) {
		return AlignmentUtil.toName( alignment );
	}

	public static TableSpec[] decodeSpecs( String encodedSpecs ) {
		if( encodedSpecs == null )
			return new TableSpec[0];

		StringTokenizer st = new StringTokenizer( encodedSpecs, ", " );
		TableSpec[] specs = new TableSpec[st.countTokens()];
		for( int i = 0; i < specs.length; i++ )
			specs[i] = new TableSpec( st.nextToken() );
		return specs;
	}

	public static String encodeSpecs( TableSpec[] specs ) {
		StringBuffer buf = new StringBuffer( specs.length * 9 );
		for( int i = 0; i < specs.length; i++ ) {
			if( i > 0 )
				buf.append( ", " );
			buf.append( specs[i].toString() );
		}
		return buf.toString();
	}
}
