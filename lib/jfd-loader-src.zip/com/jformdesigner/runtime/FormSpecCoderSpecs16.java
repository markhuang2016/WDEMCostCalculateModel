/*
 * Copyright (c) 2012 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import com.jgoodies.forms.layout.FormSpecs;

/**
 * @author Karl Tauber
 * @since 5.2
 */
class FormSpecCoderSpecs16
{
	static final Object[] columnSpecs = {
		"min",			FormSpecs.MIN_COLSPEC,
		"m",			FormSpecs.MIN_COLSPEC,
		"pref",			FormSpecs.PREF_COLSPEC,
		"p",			FormSpecs.PREF_COLSPEC,
		"default",		FormSpecs.DEFAULT_COLSPEC,
		"d",			FormSpecs.DEFAULT_COLSPEC,
		"glue",			FormSpecs.GLUE_COLSPEC,
		"relgap",		FormSpecs.RELATED_GAP_COLSPEC,
		"rgap",			FormSpecs.RELATED_GAP_COLSPEC,
		"gap",			FormSpecs.RELATED_GAP_COLSPEC,
		"unrelgap",		FormSpecs.UNRELATED_GAP_COLSPEC,
		"ugap",			FormSpecs.UNRELATED_GAP_COLSPEC,
		"labelcompgap",	FormSpecs.LABEL_COMPONENT_GAP_COLSPEC,
		"lcgap",		FormSpecs.LABEL_COMPONENT_GAP_COLSPEC,
		"button",		FormSpecs.BUTTON_COLSPEC,
		"growbutton",	FormSpecs.GROWING_BUTTON_COLSPEC,
		"gbutton",		FormSpecs.GROWING_BUTTON_COLSPEC,
	};

	static final Object[] rowSpecs = {
		"min",			FormSpecs.MIN_ROWSPEC,
		"m",			FormSpecs.MIN_ROWSPEC,
		"pref",			FormSpecs.PREF_ROWSPEC,
		"p",			FormSpecs.PREF_ROWSPEC,
		"default",		FormSpecs.DEFAULT_ROWSPEC,
		"d",			FormSpecs.DEFAULT_ROWSPEC,
		"glue",			FormSpecs.GLUE_ROWSPEC,
		"relgap",		FormSpecs.RELATED_GAP_ROWSPEC,
		"rgap",			FormSpecs.RELATED_GAP_ROWSPEC,
		"gap",			FormSpecs.RELATED_GAP_ROWSPEC,
		"unrelgap",		FormSpecs.UNRELATED_GAP_ROWSPEC,
		"ugap",			FormSpecs.UNRELATED_GAP_ROWSPEC,
		"labelcompgap",	FormSpecs.LABEL_COMPONENT_GAP_ROWSPEC,
		"narrowlinegap",FormSpecs.NARROW_LINE_GAP_ROWSPEC,
		"nlinegap",		FormSpecs.NARROW_LINE_GAP_ROWSPEC,
		"linegap",		FormSpecs.LINE_GAP_ROWSPEC,
		"pargap",		FormSpecs.PARAGRAPH_GAP_ROWSPEC,
	};
}
