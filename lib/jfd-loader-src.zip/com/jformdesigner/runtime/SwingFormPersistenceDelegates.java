/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.awt.*;
import java.beans.*;
import java.lang.reflect.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import com.jgoodies.forms.factories.Borders;
import com.jgoodies.forms.layout.CellConstraints;
import com.jformdesigner.model.*;
import com.jformdesigner.runtime.FormPersistenceDelegates;
import com.jformdesigner.runtime.FormPersistenceDelegates.DefaultPersistenceDelegateEx;
import com.jformdesigner.runtime.FormPersistenceDelegates.Fields_PersistenceDelegate;

/**
 * @author Karl Tauber
 * @since 6.0
 */
class SwingFormPersistenceDelegates
{
	static void initializePersistenceDelegates( HashMap<String, PersistenceDelegate> map ) {
		map.put( SwingBorder.class.getName(), new DefaultPersistenceDelegate( new String[] { "key" } ) );
		map.put( SwingColor.class.getName(), new DefaultPersistenceDelegate( new String[] { "key" } ) );
		map.put( SwingDerivedFont.class.getName(), new DefaultPersistenceDelegateEx( new String[] { "nameChange", "styleChange", "sizeChange", "absoluteSize" } ) );
		map.put( SwingFont.class.getName(), new DefaultPersistenceDelegate( new String[] { "key" } ) );
		map.put( SwingIcon.class.getName(), new DefaultPersistenceDelegate( new String[] { "type", "name" } ) );
		map.put( SwingTableModel.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "dataVector", "columnNames", "columnTypes", "columnEditables", "columnInfos" } ) );
		map.put( SwingTableColumn.class.getName(), new DefaultPersistenceDelegate(
			new String[] { "values", "preferredWidth", "minWidth", "maxWidth", "resizable" } ) );

		// JGoodies Forms
		map.put( CellConstraints.Alignment.class.getName(), new CellConstraints_Alignment_PersistenceDelegate() );
		map.put( Borders.EmptyBorder.class.getName(), new Borders_EmptyBorder_PersistenceDelegate() );

		//---- optimized to reduce XML file size ----

		map.put( "javax.swing.SpinnerNumberModel", new SpinnerNumberModel_PersistenceDelegate() );

		//---- fix bugs in Sun's Java implementation ----

		// Sun's implementation does not save "roundedCorners"
		map.put( "javax.swing.border.LineBorder", new DefaultPersistenceDelegate(
			new String[] { "lineColor", "thickness", "roundedCorners" } ) );

		map.put( "javax.swing.border.MatteBorder", new MatteBorder_PersistenceDelegate() );
		map.put( "javax.swing.border.TitledBorder", new TitledBorder_PersistenceDelegate() );

		// Sun's implementation uses wrong property names
		map.put( "javax.swing.border.SoftBevelBorder", new DefaultPersistenceDelegate(
			new String[] { "bevelType", "highlightOuterColor", "highlightInnerColor",
						   "shadowOuterColor", "shadowInnerColor" } ) );

		map.put( "java.awt.Color", new Color_PersistenceDelegate() );
		map.put( "java.awt.ComponentOrientation", new Fields_PersistenceDelegate( ComponentOrientation.class ) );
		map.put( "java.awt.GradientPaint", new GradientPaint_PersistenceDelegate() );
		map.put( "javax.swing.KeyStroke", new KeyStroke_PersistenceDelegate() );
		map.put( "javax.swing.DefaultListModel", new DefaultListModel_PersistenceDelegate() );
		map.put( "javax.swing.table.DefaultTableModel", new DefaultTableModel_PersistenceDelegate() );
		map.put( "javax.swing.tree.DefaultTreeModel", new DefaultPersistenceDelegate(
			new String[] { "root" } ) );

		// Java 6
		map.put( "javax.swing.border.EmptyBorder", new EmptyBorder_PersistenceDelegate() );

		// Java 7
		map.put( "java.awt.Dimension", new Dimension_PersistenceDelegate() );
		map.put( "java.awt.Point", new Point_PersistenceDelegate() );
		map.put( "java.awt.Rectangle", new Rectangle_PersistenceDelegate() );

		//---- fix bugs in IBM J9 VM ----

		if( "IBM J9 VM".equals( System.getProperty( "java.vm.name" ) ) ) {
			map.put( "java.awt.Font", new DefaultPersistenceDelegate( new String[] { "name", "style", "size" } ) );

			map.put( "javax.swing.border.BevelBorder", new DefaultPersistenceDelegate( new String[] { "bevelType", "highlightOuterColor", "highlightInnerColor", "shadowOuterColor", "shadowInnerColor" } ) );
			map.put( "javax.swing.border.EtchedBorder", new DefaultPersistenceDelegate( new String[]{ "etchType", "highlightColor", "shadowColor" } ) );
		}
	}

	//---- inner class CellConstraints_Alignment_PersistenceDelegate ----------

	private static class CellConstraints_Alignment_PersistenceDelegate
		extends PersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			String fieldName = oldInstance.toString().toUpperCase();
			try {
				return new Expression( oldInstance, CellConstraints.class.getField(fieldName),
						"get", new Object[] { null } );
			} catch( Exception ex ) {
				throw FormPersistenceDelegates.newUnrecognizedInstance( oldInstance );
			}
		}
	}

	//---- inner class Borders_EmptyBorder_PersistenceDelegate ----------------

	private static class Borders_EmptyBorder_PersistenceDelegate
		extends Fields_PersistenceDelegate
	{
		public Borders_EmptyBorder_PersistenceDelegate() {
			super( Borders.class );
		}

		@Override
		protected Expression instantiate2( Object oldInstance, Encoder out ) {
			Borders.EmptyBorder border = (Borders.EmptyBorder) oldInstance;
			String encodedSizes = FormSpecCoder.encodeSize( border.top() )
						 + ", " + FormSpecCoder.encodeSize( border.left() )
						 + ", " + FormSpecCoder.encodeSize( border.bottom() )
						 + ", " + FormSpecCoder.encodeSize( border.right() );
			return new Expression( oldInstance, Borders.class, "createEmptyBorder",
									new Object[] { encodedSizes } );
		}
	}

	//---- class EmptyBorder_PersistenceDelegate ------------------------------

	private static class EmptyBorder_PersistenceDelegate
		extends PersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			EmptyBorder border = (EmptyBorder) oldInstance;
			Insets insets = border.getBorderInsets();
			return new Expression( border, EmptyBorder.class, "new",
				new Object[] { insets.top, insets.left, insets.bottom, insets.right } );
		}
	}

	//---- class MatteBorder_PersistenceDelegate ------------------------------

	private static class MatteBorder_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			MatteBorder border = (MatteBorder) oldInstance;
			Insets insets = RuntimeUtils.getRawMatteBorderInsets( border );
			Color matteColor = border.getMatteColor();
			Icon tileIcon = border.getTileIcon();

			return new Expression( oldInstance, MatteBorder.class, "new",
				new Object[] { insets.top, insets.left, insets.bottom, insets.right,
							   (matteColor != null) ? matteColor : tileIcon } );
		}
	}

	//---- class TitledBorder_PersistenceDelegate -----------------------------

	private static class TitledBorder_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			TitledBorder border = (TitledBorder) oldInstance;
			Border tBorder = RuntimeUtils.getRawTitledBorderBorder( border );
			String title = border.getTitle();
			int titleJustification = border.getTitleJustification();
			int titlePosition = RuntimeUtils.getRawTitledBorderPosition( border );
			Font titleFont = RuntimeUtils.getRawTitledBorderFont( border );
			Color titleColor = RuntimeUtils.getRawTitledBorderColor( border );

			// store as few properties as possible because title position has
			// different default values on different Java versions
			Object[] args;
			if( titleFont != null || titleColor != null )
				args = new Object[] { tBorder, title, titleJustification, titlePosition, titleFont, titleColor };
			else if( titleJustification != RuntimeUtils.defaultTitleJustification || titlePosition != RuntimeUtils.defaultTitlePosition )
				args = new Object[] { tBorder, title, titleJustification, titlePosition };
			else if( tBorder != null )
				args = new Object[] { tBorder, title };
			else
				args = new Object[] { title };
			return new Expression( oldInstance, TitledBorder.class, "new", args );
		}
	}

	//---- inner class Color_PersistenceDelegate ------------------------------

	private static class Color_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		Color_PersistenceDelegate() {
			super( new String[] { "red", "green", "blue", "alpha" } );
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			try {
				Field[] fields = Color.class.getFields();
				for( Field field : fields ) {
					if( oldInstance == field.get( null ) )
						return new Expression( oldInstance, field, "get", new Object[] { null } );
				}

				return super.instantiate( oldInstance, out );
			} catch( Exception ex ) {
				throw FormPersistenceDelegates.newUnrecognizedInstance( oldInstance );
			}
		}
	}

	//---- class Dimension_PersistenceDelegate --------------------------------

	private static class Dimension_PersistenceDelegate
		extends PersistenceDelegate
	{
		@Override
		protected boolean mutatesTo( Object oldInstance, Object newInstance ) {
			return oldInstance.equals( newInstance );
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			Dimension dimension = (Dimension) oldInstance;
			return new Expression( dimension, dimension.getClass(), "new",
				new Object[] { dimension.width, dimension.height } );
		}
	}

	//---- class Point_PersistenceDelegate ------------------------------------

	private static class Point_PersistenceDelegate
		extends PersistenceDelegate
	{
		@Override
		protected boolean mutatesTo( Object oldInstance, Object newInstance ) {
			return oldInstance.equals( newInstance );
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			Point point = (Point) oldInstance;
			return new Expression( point, point.getClass(), "new",
				new Object[] { point.x, point.y } );
		}
	}

	//---- class Rectangle_PersistenceDelegate --------------------------------

	private static class Rectangle_PersistenceDelegate
		extends PersistenceDelegate
	{
		@Override
		protected boolean mutatesTo( Object oldInstance, Object newInstance ) {
			return oldInstance.equals( newInstance );
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			Rectangle rectangle = (Rectangle) oldInstance;
			return new Expression( rectangle, rectangle.getClass(), "new",
				new Object[] { rectangle.x, rectangle.y, rectangle.width, rectangle.height } );
		}
	}

	//---- class GradientPaint_PersistenceDelegate ----------------------------

	private static class GradientPaint_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			GradientPaint gradientPaint = (GradientPaint) oldInstance;
			return new Expression( oldInstance, GradientPaint.class, "new",
				new Object[] {
					new Float( gradientPaint.getPoint1().getX() ),
					new Float( gradientPaint.getPoint1().getY() ),
					gradientPaint.getColor1(),
					new Float( gradientPaint.getPoint2().getX() ),
					new Float( gradientPaint.getPoint2().getY() ),
					gradientPaint.getColor2(),
					gradientPaint.isCyclic()
				} );
		}
	}

	//---- inner class KeyStroke_PersistenceDelegate --------------------------

	private static class KeyStroke_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			KeyStroke keyStroke = (KeyStroke) oldInstance;
			return new Expression( oldInstance, KeyStroke.class, "getKeyStroke",
				new Object[] { keyStroke.getKeyCode(),
							   keyStroke.getModifiers(),
							   keyStroke.isOnKeyRelease() } );
		}
	}

	//---- inner class DefaultListModel_PersistenceDelegate -------------------

	private static class DefaultListModel_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected void initialize( Class<?> type, Object oldInstance,
								   Object newInstance, Encoder out )
		{
			DefaultListModel m = (DefaultListModel) oldInstance;
			for( int i = 0; i < m.getSize(); i++ ) {
				out.writeStatement( new Statement( oldInstance, "addElement",
					new Object[] { m.getElementAt( i ) } ) );
			}
		}
	}

	//---- inner class DefaultTableModel_PersistenceDelegate ------------------

	private static class DefaultTableModel_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			DefaultTableModel model = (DefaultTableModel) oldInstance;
			int columnCount = model.getColumnCount();
			Vector<?> data = model.getDataVector();
			Vector<Object> columnNames = new Vector<Object>( columnCount );
			for( int i = 0; i < columnCount; i++ )
				columnNames.add( model.getColumnName( i ) );

			return new Expression( oldInstance, DefaultTableModel.class, "new",
				new Object[] { data, columnNames } );
		}
	}

	//---- class SpinnerNumberModel_PersistenceDelegate -----------------------

	private static class SpinnerNumberModel_PersistenceDelegate
		extends DefaultPersistenceDelegate
	{
		SpinnerNumberModel_PersistenceDelegate() {
			super( new String[] { "value", "minimum", "maximum", "stepSize" } );
		}

		@Override
		protected Expression instantiate( Object oldInstance, Encoder out ) {
			SpinnerNumberModel model = (SpinnerNumberModel) oldInstance;
			if( model.getMinimum() == null || model.getMaximum() == null ) {
				// Use default constructor if minimum or maximum are null
				// to avoid problems with decoding on some VMs, where the
				// decoder tries to invoke the wrong constructor.
				return new Expression( oldInstance, oldInstance.getClass(), "new", new Object[0] );
			} else
				return super.instantiate( oldInstance, out );
		}
	}
}
